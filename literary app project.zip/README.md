## **Literary Book Application**
An application that showcases a simple Book purchasing website.
#### Created using Javscript, HTML/CSS with basic functionalities like login page, Registeration, Become a member of a book club and add to cart.

Screenshots:

**Home Page:**

![Home1](https://github.com/user-attachments/assets/d8405cea-f62e-409c-8017-7845980ea61f)

![Home2](https://github.com/user-attachments/assets/8e2c15c4-e841-463f-9d47-4be09a512cdd)

![Home3](https://github.com/user-attachments/assets/ae5610d2-976a-4a86-a314-f066ab23e181)

![Home4](https://github.com/user-attachments/assets/df6a6d65-68b4-4402-b6dc-70a9a9d330ac)


**Sign In:**


![signin](https://github.com/user-attachments/assets/db6e5c7f-7b70-4ebd-9070-f1306c30a7aa)


**Member:**

![member](https://github.com/user-attachments/assets/da20e518-eb10-457b-93bf-5c76896a6e74)


**Add To Cart:**

![addtocart](https://github.com/user-attachments/assets/9f0ff8bb-2cea-4170-9b9e-e0ec22246092)
